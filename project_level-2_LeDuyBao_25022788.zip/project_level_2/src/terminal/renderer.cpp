/**
 * Ternimal Renderer cpp implementation
 *
 */

#include "renderer.h"

/* ---------- Importing ---------- */

#include <format>
#include <iostream>
#include <iomanip>

#include "../game/setup.h"
#include "../utils/config.h"

/* ---------- Definitions ---------- */

/**
 * Mô tả:
 *   Constructor của TerminalRenderer.
 *
 * TODO:
 *   - Khởi tạo trạng thái ban đầu nếu cần
 */
TerminalRenderer::TerminalRenderer() : I_Renderer() {}

/**
 * Mô tả:
 *   Destructor của TerminalRenderer.
 *
 * TODO:
 *   - Giải phóng tài nguyên nếu có
 */
TerminalRenderer::~TerminalRenderer() {}

/**
 * Mô tả:
 *   Khởi tạo renderer với config.
 *
 * TODO:
 *   - Đọc config
 *   - Thiết lập môi trường hiển thị
 */
void TerminalRenderer::init(const RunConfig& config) {
    // terminal không cần init gì thêm
}

/**
 * Mô tả:
 *   Xóa màn hình terminal.
 *
 * TODO:
 *   - Sử dụng ANSI escape sequence để clear screen
 */
void TerminalRenderer::clearScreen() {
    std::cout << "\n" << "\x1B[2J\x1B[H" << "\n";
}

/**
 * Mô tả:
 *   Hiển thị menu lựa chọn.
 *
 * TODO:
 *   - Bước 1: kiểm tra selectType
 *   - Bước 2: in menu tương ứng
 *   - Trường hợp biên: selectType không hợp lệ
 */
void TerminalRenderer::showSelectMenu(SelectType selectType, int context) {
    switch (selectType) {
        case SelectType::TITLE_UI:
            std::cout << std::format(">----- Tic-tac-toe [Console v{}] -----<\n\n", VERSION);
            break;
        case SelectType::SIZE_UI:
            std::cout << std::format("Size Input (NxN, 3 <= N <= {}): ", BOARD_N_MAX);
            break;
        case SelectType::GOAL_UI:
            // context là size hiện tại
            if (context != NO_CONTEXT)
                std::cout << std::format("Goal Input (3 <= goal <= {}): ", std::min(context, GOAL_MAX));
            else
                std::cout << "Goal Input (3 <= goal <= 5): ";
            break;
        case SelectType::GAME_MODE_UI:
            std::cout << "(1) PvP | (2) PvE | (3) EvE: ";
            break;
        case SelectType::BOT_LEVEL_UI:
            std::cout << "(1) EASY | (2) MEDIUM | (3) HARD: ";
            break;
        case SelectType::PLAYER_UI:
            std::cout << "Your move (row col): ";
            break;
        case SelectType::MUL_BOT_LEVEL_UI:
            // context là index bot (0 hoặc 1)
            if (context != NO_CONTEXT)
                std::cout << std::format("Bot {} level - (1) EASY | (2) MEDIUM | (3) HARD: ", context + 1);
            else
                std::cout << "(1) EASY | (2) MEDIUM | (3) HARD: ";
            break;
        default:
            break;
    }
}


/**
 * Mô tả:
 *   Hiển thị thông báo lựa chọn không hợp lệ.
 *
 * TODO:
 *   - Bước 1: xác định loại lỗi
 *   - Bước 2: in thông báo tương ứng
 */
void TerminalRenderer::showInvalidSelect(SelectType selectType, int context) {
    std::cout << "Invalid input! Please try again.\n";
}
/**
 * Mô tả:
 *   Hiển thị thông báo lựa chọn hợp lệ.
 *
 * TODO:
 *   - Bước 1: xác định loại select
 *   - Bước 2: in thông báo xác nhận
 */
void TerminalRenderer::showValidSelect(SelectType selectType, int context) {
    switch (selectType) {
        case SelectType::SIZE_UI:
            std::cout << std::format("Board size: {}x{}\n", context, context);
            break;
        case SelectType::GOAL_UI:
            std::cout << std::format("Goal: {}\n", context);
            break;
        case SelectType::GAME_MODE_UI:
            std::cout << std::format("Mode: {}\n", modeToString(context));
            break;
        case SelectType::BOT_LEVEL_UI:
        case SelectType::MUL_BOT_LEVEL_UI:
            std::cout << std::format("Bot level: {}\n", botToString(context));
            break;
        default:
            break;
    }
}

/**
 * Mô tả:
 *   Hiển thị bàn cờ.
 *
 * TODO:
 *   - Bước 1: in header
 *   - Bước 2: in trục tọa độ
 *   - Bước 3: duyệt board và in từng ô
 */
void TerminalRenderer::displayBoard(const char board[][BOARD_N_MAX], const int size) {
    // in số cột
    std::cout << "   ";
    for (int j = 0; j < size; j++) {
        std::cout << std::setw(3) << j;
    }
    std::cout << "\n";

    // in từng hàng
    for (int i = 0; i < size; i++) {
        std::cout << std::setw(3) << i;
        for (int j = 0; j < size; j++) {
            std::cout << std::setw(3) << board[i][j];
        }
        std::cout << "\n";
    }
    std::cout << "\n";
}

/**
 * Mô tả:
 *   Hiển thị thông tin player hiện tại.
 *
 * TODO:
 *   - In player index
 *   - Nếu là bot thì thêm label "(Bot)"
 */
void TerminalRenderer::showPlayer(const int player, const bool is_bot) {
    if (is_bot) {
        std::cout << std::format("Bot (Player {}) is thinking...\n", player + 1);
    } else {
        std::cout << std::format("Player {}'s turn\n", player + 1);
    }
}

/**
 * Mô tả:
 *   Hiển thị nước đi vừa thực hiện.
 *
 * TODO:
 *   - In ra tọa độ (row, col)
 */
void TerminalRenderer::showMove(const int row, const int col) {
    std::cout << std::format("Move placed at ({}, {})\n", row, col);
}

/**
 * Mô tả:
 *   Hiển thị thông báo nước đi không hợp lệ.
 *
 * TODO:
 *   - In message lỗi
 */
void TerminalRenderer::showInvalidMove() {
    std::cout << "Invalid move! Please try again.\n";
}

/**
 * Mô tả:
 *   Hiển thị kết quả game.
 *
 * TODO:
 *   - Bước 1: kiểm tra draw hoặc winner
 *   - Bước 2: in kết quả
 *   - Trường hợp biên: winner = -1
 */
void TerminalRenderer::showResult(const int winner, const bool is_bot, const WinLine* winLine) {
    if (winner == DRAW_RESULT) {
        std::cout << "It's a draw!\n";
    } else if (is_bot) {
        std::cout << std::format("Bot (Player {}) wins!\n", winner + 1);
    } else {
        std::cout << std::format("Player {} wins!\n", winner + 1);
    }
}

/**
 * Mô tả:
 *   In kết quả đơn giản (judge mode).
 *
 * TODO:
 *   - In winner và số lượt
 */
void TerminalRenderer::printResult(const GameResult& gameResult) {
    std::cout << gameResult.winner << " " << gameResult.turns << "\n";
}

/**
 * Mô tả:
 *   Đóng renderer.
 *
 * TODO:
 *   - Giải phóng tài nguyên nếu có
 */
void TerminalRenderer::close() {
    // terminal không cần cleanup gì
}