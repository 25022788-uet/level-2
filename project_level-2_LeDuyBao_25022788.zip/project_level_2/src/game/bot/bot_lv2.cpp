/**
 * Bot LV2 cpp implementation
 *
 */

#include "bot_lv2.h"

/* ---------- Importing ---------- */

#include <sstream>

#include "../../utils/logger.h"
#include "../logic.h"

/* ---------- Definitions ---------- */

/**
 * Mô tả:
 *   Constructor của BotLevel2.
 */
BotLevel2::BotLevel2(const BotLevel& _level, const char& _symbol)
    : BotLevel1(_level, _symbol) {
}

/**
 * Mô tả:
 *   Destructor của BotLevel2.
 */
BotLevel2::~BotLevel2() {
}

/**
 * Mô tả:
 *   Trả về nước đi của bot MEDIUM.
 *
 * TODO:
 *   - Gọi heuristic để chọn nước đi
 */
pII BotLevel2::getMove(char board[][BOARD_N_MAX], const int size, const int goal) {
    return simple_heuristic(board, size, goal, symbol, op_symbol);
}

/**
 * Mô tả:
 *   Heuristic đơn giản:
 *   - Ưu tiên thắng
 *   - Chặn đối thủ
 *   - Fallback random
 *
 * TODO:
 *   - Bước 1: kiểm tra nước thắng
 *   - Bước 2: kiểm tra nước chặn
 *   - Bước 3: chọn random nếu không có
 */
pII BotLevel2::simple_heuristic(char board[][BOARD_N_MAX], const int size, const int goal, const char botSymbol, const char playerSymbol) {
    // 1. thử xem bot có nước thắng không
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            if (board[i][j] == '-') {
                board[i][j] = botSymbol;
                if (Logic::checkWin(board, size, botSymbol, goal)) {
                    board[i][j] = '-';
                    Logger::log("[BotLv2] found winning move", Logger::Level::DEBUG);
                    return {i, j};
                }
                board[i][j] = '-';
            }
        }
    }

    // 2. chặn nước thắng của đối thủ
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            if (board[i][j] == '-') {
                board[i][j] = playerSymbol;
                if (Logic::checkWin(board, size, playerSymbol, goal)) {
                    board[i][j] = '-';
                    Logger::log("[BotLv2] blocking opponent", Logger::Level::DEBUG);
                    return {i, j};
                }
                board[i][j] = '-';
            }
        }
    }

    // 3. ưu tiên ô trung tâm
    int center = size / 2;
    if (board[center][center] == '-') {
        Logger::log("[BotLv2] picking center", Logger::Level::DEBUG);
        return {center, center};
    }

    // 4. ưu tiên ô gần quân cờ đã có
    int bestScore = -1;
    pII bestCell = {-1, -1};

    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            if (board[i][j] != '-') continue;

            int score = 0;
            for (int di = -2; di <= 2; di++) {
                for (int dj = -2; dj <= 2; dj++) {
                    if (di == 0 && dj == 0) continue;
                    int ni = i + di;
                    int nj = j + dj;
                    if (ni < 0 || ni >= size) continue;
                    if (nj < 0 || nj >= size) continue;
                    if (board[ni][nj] == botSymbol) score += 2;
                    else if (board[ni][nj] == playerSymbol) score += 1;
                }
            }

            if (score > bestScore) {
                bestScore = score;
                bestCell = {i, j};
            }
        }
    }

    if (bestCell.first != -1) {
        Logger::log("[BotLv2] picking near existing piece", Logger::Level::DEBUG);
        return bestCell;
    }

    // 5. fallback random
    return random_pick(board, size);
}