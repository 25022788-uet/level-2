/**
 * Logic cpp implementation
 *
 */

#include "logic.h"

/* ---------- Importing ---------- */

#include <format>
#include <limits>
#include <sstream>
#include <optional>
#include <vector>

#include "../utils/logger.h"

/* ---------- Definitions ---------- */

/**
 * Mô tả: Khởi tạo bàn cờ với ký tự mặc định.
 * Đầu vào: board, size
 * Đầu ra: Không có
 * Tác dụng phụ: Ghi dữ liệu vào board
 * TODO:
 */
void Logic::initBoard(char board[][BOARD_N_MAX], const int size) {
    for (int i = 0; i < size; i++)
        for (int j = 0; j < size; j++)
            board[i][j] = '-';
}

/**
 * Mô tả: Kiểm tra nước đi có hợp lệ không.
 * Đầu vào: board, size, row, col
 * Đầu ra: true nếu hợp lệ
 * Tác dụng phụ: Không có
 * TODO:
 */
bool Logic::isValidMove(const char board[][BOARD_N_MAX], const int size, const int row, const int col) {
    if (row < 0 || row >= size) return false;
    if (col < 0 || col >= size) return false;
    if (board[row][col] != '-') return false;
    return true;
}

/**
 * Mô tả: Thực hiện một nước đi.
 * Đầu vào: board, row, col, symbol
 * Đầu ra: Không có
 * Tác dụng phụ: Ghi vào board
 * TODO:
 */
void Logic::makeMove(char board[][BOARD_N_MAX], const int row, const int col, const char symbol) {
    board[row][col] = symbol;
}

/**
 * Mô tả: Kiểm tra một ô có phải là đầu mở hay không.
 * Đầu vào: board, size, x, y, symbol
 * Đầu ra: true nếu là đầu mở
 * Tác dụng phụ: Không có
 * TODO:
 */
bool Logic::isEmptyHead(const char board[][BOARD_N_MAX], const int size, int x, int y, const char symbol) {
    if (x < 0 || x >= size) return true;
    if (y < 0 || y >= size) return true;
    if (board[x][y] == '-') return true;
    if (board[x][y] == symbol) return true;
    return false;
}

/**
 * Mô tả: Kiểm tra điều kiện thắng.
 * Đầu vào: board, size, symbol, goal, rule
 * Đầu ra: true nếu thắng
 * Tác dụng phụ: Có thể log debug
 * TODO:
 */
bool Logic::checkWin(char board[][BOARD_N_MAX], const int size, const char symbol, const int goal, EndRule rule) {
    int dr[] = {0, 1, 1,  1};
    int dc[] = {1, 0, 1, -1};

    for (int r = 0; r < size; r++) {
        for (int c = 0; c < size; c++) {
            if (board[r][c] != symbol) continue;
            for (int d = 0; d < 4; d++) {
                int count = 0;
                for (int k = 0; k < goal; k++) {
                    int nr = r + dr[d] * k;
                    int nc = c + dc[d] * k;
                    if (nr < 0 || nr >= size) break;
                    if (nc < 0 || nc >= size) break;
                    if (board[nr][nc] != symbol) break;
                    count++;
                }

                if (count == goal) {
                    if (rule == EndRule::NONE) return true;

                    int prevR = r - dr[d];
                    int prevC = c - dc[d];
                    int nextR = r + dr[d] * goal;
                    int nextC = c + dc[d] * goal;

                    bool openPrev = isEmptyHead(board, size, prevR, prevC, symbol);
                    bool openNext = isEmptyHead(board, size, nextR, nextC, symbol);

                    if (rule == EndRule::OPEN_ONE && (openPrev || openNext)) return true;
                    if (rule == EndRule::OPEN_TWO && openPrev && openNext) return true;
                }
            }
        }
    }
    return false;
}

/**
 * Mô tả: Kiểm tra trạng thái hòa.
 * Đầu vào: board, size
 * Đầu ra: true nếu hòa
 * Tác dụng phụ: Không có
 * TODO:
 */
bool Logic::checkDraw(char board[][BOARD_N_MAX], const int size) {
    for (int i = 0; i < size; i++)
        for (int j = 0; j < size; j++)
            if (board[i][j] == '-') return false;
    return true;
}

/**
 * Mô tả: Lấy đường thắng nếu tồn tại.
 * Đầu vào: board, size, symbol, goal, rule
 * Đầu ra: optional WinLine
 * Tác dụng phụ: Không có
 * TODO:
 */
std::optional<WinLine> Logic::getWinLine(
    const char board[][BOARD_N_MAX],
    const int size,
    const char symbol,
    const int goal,
    EndRule rule) {

    int dr[] = {0, 1, 1,  1};
    int dc[] = {1, 0, 1, -1};

    for (int r = 0; r < size; r++) {
        for (int c = 0; c < size; c++) {
            if (board[r][c] != symbol) continue;
            for (int d = 0; d < 4; d++) {
                int count = 0;
                for (int k = 0; k < goal; k++) {
                    int nr = r + dr[d] * k;
                    int nc = c + dc[d] * k;
                    if (nr < 0 || nr >= size) break;
                    if (nc < 0 || nc >= size) break;
                    if (board[nr][nc] != symbol) break;
                    count++;
                }

                if (count == goal) {
                    bool valid = false;
                    if (rule == EndRule::NONE) {
                        valid = true;
                    } else {
                        int prevR = r - dr[d];
                        int prevC = c - dc[d];
                        int nextR = r + dr[d] * goal;
                        int nextC = c + dc[d] * goal;

                        bool openPrev = isEmptyHead(board, size, prevR, prevC, symbol);
                        bool openNext = isEmptyHead(board, size, nextR, nextC, symbol);

                        if (rule == EndRule::OPEN_ONE && (openPrev || openNext)) valid = true;
                        if (rule == EndRule::OPEN_TWO && openPrev && openNext) valid = true;
                    }

                    if (valid) {
                        // thu thập các ô tạo thành đường thắng
                        WinLine winLine;
                        for (int k = 0; k < goal; k++) {
                            winLine.cells.push_back({
                                r + dr[d] * k,
                                c + dc[d] * k
                            });
                        }
                        return winLine;
                    }
                }
            }
        }
    }
    return std::nullopt;  // không tìm thấy đường thắng
}