/**
 * SDL Interaction header file
 *
 */

#pragma once

/* ---------- Importing ---------- */

#include <SDL2/SDL.h>

#include "../game/interface/i_interaction.h"
#include "../game/setup.h"
#include "../utils/config.h"

/* ---------- Declarations ---------- */

/**
 * Mô tả: Lớp xử lý tương tác người dùng sử dụng SDL (event-based).
 * Đầu vào: Không (khởi tạo qua init với RunConfig).
 * Đầu ra: Không.
 * Tác dụng phụ:
 *   - Lắng nghe và xử lý SDL events (keyboard, mouse, quit,...).
 *   - Điều khiển luồng input cho game GUI.
 * NOTE: Hoạt động theo mô hình event loop, khác với terminal input.
 */
class SDLInteraction : public I_Interaction {
   private:
    /**
     * Mô tả: Chờ event quit (đóng cửa sổ) từ người dùng.
     * Đầu vào: e - SDL_Event để lưu sự kiện nhận được.
     * Đầu ra: true nếu nhận được quit event, false nếu không.
     * Tác dụng phụ: Block cho đến khi có event.
     */
    bool waitForQuit(SDL_Event& e);
    int boardSize = 3; // tạm thời lưu board size để map tọa độ
    int screenWidth = 800;
    int screenHeight = 600;
    int boardPadding = 100;

   public:
    /**
     * Mô tả: Constructor khởi tạo SDLInteraction.
     * Đầu vào: Không.
     * Đầu ra: Không.
     * Tác dụng phụ: Không.
     */
    SDLInteraction();

    /**
     * Mô tả: Destructor của SDLInteraction.
     * Đầu vào: Không.
     * Đầu ra: Không.
     * Tác dụng phụ: Không.
     */
    ~SDLInteraction();

    /**
     * Mô tả: Khởi tạo hệ thống interaction cho SDL.
     * Đầu vào: config - cấu hình runtime.
     * Đầu ra: Không.
     * Tác dụng phụ:
     *   - Chuẩn bị môi trường nhận event.
     */
    void init(const RunConfig& config) override;
    void setBoardSize(int size) { boardSize = size; }  // thêm setter
    /**
     * Mô tả: Tạm dừng chương trình.
     * Đầu vào: timeout - thời gian chờ (ms), nếu = 0 thì chờ event.
     * Đầu ra: Không.
     * Tác dụng phụ:
     *   - Có thể block thread.
     * NOTE: Có thể dùng để chờ click hoặc delay frame.
     */
    void pause(int timeout = 0) override;

    /**
     * Mô tả: Nhận input kích thước bàn cờ từ người dùng (qua event).
     * Đầu vào: size - con trỏ lưu kết quả.
     * Đầu ra: true nếu hợp lệ, false nếu không.
     * Tác dụng phụ: Đọc event từ SDL.
     */
    bool selectSize(int* size) override;

    /**
     * Mô tả: Nhận input goal (điều kiện thắng).
     * Đầu vào:
     *   - goal: con trỏ lưu kết quả.
     *   - size: kích thước bàn cờ.
     * Đầu ra: true nếu hợp lệ, false nếu không.
     * Tác dụng phụ: Đọc event từ SDL.
     */
    bool selectGoal(int* goal, const int size) override;

    /**
     * Mô tả: Nhận input chế độ chơi.
     * Đầu vào: mode - con trỏ lưu GameMode.
     * Đầu ra: true nếu hợp lệ, false nếu không.
     * Tác dụng phụ: Đọc event từ SDL.
     */
    bool selectGameMode(GameMode* mode) override;

    /**
     * Mô tả: Nhận input level cho bot.
     * Đầu vào:
     *   - levels: mảng BotLevel.
     *   - index: vị trí bot cần set.
     * Đầu ra: true nếu hợp lệ, false nếu không.
     * Tác dụng phụ: Đọc event từ SDL.
     */
    bool selectBotLevel(BotLevel* levels, const int index) override;

    /**
     * Mô tả: Nhận nước đi của người chơi (qua mouse/keyboard).
     * Đầu vào: row, col - con trỏ lưu tọa độ.
     * Đầu ra: true nếu lấy được nước đi hợp lệ, false nếu không.
     * Tác dụng phụ:
     *   - Đọc event chuột hoặc bàn phím.
     * NOTE: Cần map tọa độ pixel -> tọa độ board.
     */
    bool getPlayerMove(int* row, int* col) override;

    /**
     * Mô tả: Đóng hệ thống interaction SDL.
     * Đầu vào: Không.
     * Đầu ra: Không.
     * Tác dụng phụ:
     *   - Giải phóng tài nguyên liên quan đến event (nếu có).
     */
    void close() override;

    /**
     * Mô tả: Lắng nghe sự kiện SDL (event polling).
     * Dùng cho state-based game loop.
     * Đầu vào: Không.
     * Đầu ra: Không.
     * Tác dụng phụ: Cập nhật trạng thái event nội bộ.
     */
    void listenEvent() override;

    /**
     * Mô tả: Xử lý sự kiện và chuyển trạng thái game.
     * Dùng cho state-based game loop.
     * Đầu vào:
     *   - currentState: trạng thái game hiện tại.
     *   - setup: thông tin setup game.
     * Đầu ra: GameState mới.
     * Tác dụng phụ: Có thể thay đổi setup nếu cần.
     */
    GameState handleEvent(GameState currentState, GameSetup& setup) override;

    /**
     * Mô tả: Chờ người dùng chọn có muốn chơi lại hay không.
     * Đầu vào: Không.
     * Đầu ra: true nếu người dùng chọn "Play Again", false nếu chọn "Quit".
     * Tác dụng phụ: Xử lý event SDL.
     */
    bool waitForPlayAgainSelection();

   private:
    SDL_Event currentEvent;      // sự kiện SDL hiện tại
    bool hasEvent = false;       // có sự kiện mới hay không
    int pendingSize = -1;        // giá trị size đang chờ xử lý
    int pendingGoal = -1;        // giá trị goal đang chờ xử lý
    GameMode pendingMode = GameMode::INVALID_MODE;  // mode đang chờ
    BotLevel pendingBotLevel = BotLevel::INVALID_LV; // bot level đang chờ
    int pendingMoveRow = -1, pendingMoveCol = -1;   // nước đi đang chờ
};