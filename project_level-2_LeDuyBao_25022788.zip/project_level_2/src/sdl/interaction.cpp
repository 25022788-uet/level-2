/**
 * SDL Interaction cpp implementation
 *
 */

#include "interaction.h"

/* ---------- Importing ---------- */

#include <format>
#include <iostream>
#include "../utils/logger.h"

/* ---------- Definitions ---------- */

/**
 * Mô tả: Kiểm tra sự kiện quit từ SDL.
 * Đầu vào:
 *   - e: SDL_Event hiện tại.
 * Đầu ra:
 *   - false nếu không phải quit event.
 * Tác dụng phụ:
 *   - Ném QuitException nếu nhận được sự kiện thoát.
 */
bool SDLInteraction::waitForQuit(SDL_Event& e) {
    if (e.type == SDL_QUIT) {
        throw QuitException();
    }
    return false;
}

/**
 * Mô tả: Khởi tạo đối tượng SDLInteraction.
 * Đầu vào: Không có.
 * Đầu ra: Không có.
 * Tác dụng phụ: Không có.
 */
SDLInteraction::SDLInteraction() {
}

/**
 * Mô tả: Destructor của SDLInteraction.
 * Đầu vào: Không có.
 * Đầu ra: Không có.
 * Tác dụng phụ: Không có.
 */
SDLInteraction::~SDLInteraction() {
}

/**
 * Mô tả: Khởi tạo hệ thống interaction cho SDL.
 * Đầu vào:
 *   - config: cấu hình runtime của chương trình.
 * Đầu ra: Không có.
 * Tác dụng phụ:
 *   - Thiết lập trạng thái ban đầu cho input SDL.
 */
void SDLInteraction::init(const RunConfig& config) {
    screenWidth = config.screenWidth;
    screenHeight = config.screenHeight;
    boardPadding = config.boardPadding;
    Logger::log("SDLInteraction initialized!");
}

static bool pointInRect(int x, int y, const SDL_Rect& rect) {
    return x >= rect.x && x < rect.x + rect.w && y >= rect.y && y < rect.y + rect.h;
}

static bool resolveGridClick(int x, int y, int count, int cols,
                             int buttonW, int buttonH, int spacing,
                             int centerX, int topY, int& outIndex) {
    int rows = (count + cols - 1) / cols;
    int totalWidth = cols * buttonW + (cols - 1) * spacing;
    int startX = centerX - totalWidth / 2;

    for (int i = 0; i < count; i++) {
        int row = i / cols;
        int col = i % cols;
        SDL_Rect rect = {
            startX + col * (buttonW + spacing),
            topY + row * (buttonH + spacing),
            buttonW,
            buttonH
        };
        if (pointInRect(x, y, rect)) {
            outIndex = i;
            return true;
        }
    }

    return false;
}

/**
 * Mô tả: Tạm dừng chương trình trong SDL.
 *        - Nếu có timeout > 0: delay trong khoảng thời gian tương ứng.
 *        - Nếu timeout == 0: chờ người dùng tương tác (nhấn phím hoặc click chuột).
 * Đầu vào:
 *   - timeout: thời gian chờ (milliseconds). Nếu = 0 thì chờ event từ người dùng.
 * Đầu ra: Không có.
 * Tác dụng phụ:
 *   - Có thể block thread hiện tại.
 *   - Có thể ném QuitException nếu người dùng đóng cửa sổ.
 */
void SDLInteraction::pause(int timeout) {
    // Nếu có timeout cụ thể -> delay trực tiếp bằng SDL
    if (timeout > 0) {
        SDL_Delay(timeout);
        return;
    }

    bool waiting = true;
    SDL_Event event;

    // Vòng lặp chờ sự kiện từ người dùng
    while (waiting) {
        // SDL_WaitEvent sẽ block cho tới khi có event
        if (SDL_WaitEvent(&event)) {
            if (waitForQuit(event)) {
            }

            // Nếu có tương tác click chuột -> kết thúc pause
            if (event.type == SDL_MOUSEBUTTONDOWN) {
                waiting = false;
            }
        }
    }
}

/**
 * Đọc input số từ bàn phím qua SDL event
 * User gõ số rồi nhấn Enter
 */
static bool sdlGetNumber(int* val) {
    std::string input;
    SDL_Event e;
    SDL_StartTextInput();

    while (SDL_WaitEvent(&e)) {
        if (e.type == SDL_QUIT) throw QuitException();

        if (e.type == SDL_KEYDOWN) {
            if (e.key.keysym.sym == SDLK_RETURN || e.key.keysym.sym == SDLK_KP_ENTER) {
                // nhấn Enter → xử lý input
                SDL_StopTextInput();
                if (input.empty()) return false;
                try {
                    *val = std::stoi(input);
                    return true;
                } catch (...) {
                    return false;
                }
            }
            if (e.key.keysym.sym == SDLK_BACKSPACE && !input.empty()) {
                input.pop_back();
            }
        }

        if (e.type == SDL_TEXTINPUT) {
            // chỉ chấp nhận ký tự số
            char c = e.text.text[0];
            if (c >= '0' && c <= '9') {
                input += c;
            }
        }
    }

    SDL_StopTextInput();
    return false;
}

/**
 * Mô tả: Lấy input kích thước bàn cờ từ người dùng qua SDL.
 * Đầu vào:
 *   - size: con trỏ lưu kết quả kích thước.
 * Đầu ra:
 *   - true nếu input hợp lệ, false nếu không hợp lệ.
 * Tác dụng phụ:
 *   - Cập nhật giá trị tại size nếu thành công.
 */
bool SDLInteraction::selectSize(int* size) {
    if (!sdlGetNumber(size)) return false;
    if (*size < 3 || *size > BOARD_N_MAX) return false;
    return true;
}

/**
 * Mô tả: Lấy input goal (số ô liên tiếp để thắng).
 * Đầu vào:
 *   - goal: con trỏ lưu giá trị goal.
 *   - size: kích thước bàn cờ hiện tại.
 * Đầu ra:
 *   - true nếu hợp lệ, false nếu không hợp lệ.
 * Tác dụng phụ:
 *   - Cập nhật goal nếu hợp lệ.
 */
bool SDLInteraction::selectGoal(int* goal, const int size) {
    if (!sdlGetNumber(goal)) return false;
    if (*goal < 3 || *goal > GOAL_MAX || *goal > size) return false;
    return true;
}
    

/**
 * Mô tả: Lấy input chế độ chơi (PVP, PVE, EVE).
 * Đầu vào:
 *   - mode: con trỏ lưu giá trị GameMode.
 * Đầu ra:
 *   - true nếu hợp lệ, false nếu không hợp lệ.
 * Tác dụng phụ:
 *   - Cập nhật mode nếu hợp lệ.
 */
bool SDLInteraction::selectGameMode(GameMode* mode) {
    int val;
    if (!sdlGetNumber(&val)) return false;
    switch (val) {
        case 1: *mode = GameMode::PVP; return true;
        case 2: *mode = GameMode::PVE; return true;
        case 3: *mode = GameMode::EVE; return true;
        default: return false;
    }
}

/**
 * Mô tả: Lấy input cấp độ bot.
 * Đầu vào:
 *   - levels: mảng lưu cấp độ bot.
 *   - index: vị trí bot cần gán.
 * Đầu ra:
 *   - true nếu hợp lệ, false nếu không hợp lệ.
 * Tác dụng phụ:
 *   - Cập nhật levels[index] nếu hợp lệ.
 */
bool SDLInteraction::selectBotLevel(BotLevel* levels, const int index) {
    int val;
    if (!sdlGetNumber(&val)) return false;
    switch (val) {
        case 1: levels[index] = BotLevel::EASY;   return true;
        case 2: levels[index] = BotLevel::MEDIUM; return true;
        case 3: levels[index] = BotLevel::HARD;   return true;
        default: return false;
    }
}

/**
 * Mô tả: Lấy nước đi từ người chơi (row, col) qua SDL (click chuột).
 * Map tọa độ pixel → tọa độ board
 * Đầu vào:
 *   - row: con trỏ lưu hàng.
 *   - col: con trỏ lưu cột.
 * Đầu ra:
 *   - true nếu lấy được input hợp lệ, false nếu không.
 * Tác dụng phụ:
 *   - Cập nhật row, col nếu hợp lệ.
 */
bool SDLInteraction::getPlayerMove(int* row, int* col) {
    SDL_Event e;
    while (SDL_WaitEvent(&e)) {
        if (e.type == SDL_QUIT) throw QuitException();

        if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT) {
            int mouseX = e.button.x;
            int mouseY = e.button.y;

            // boardPadding và cellSize được tính trong renderer
            // cần lấy từ config hoặc tính lại
            // dùng giá trị mặc định: padding=100, cellSize tính theo screenW
            int padding = 100;
            int screenW = 800;
            int boardW = screenW - 2 * padding;

            // chờ đến khi biết BOARD_SIZE từ gameSetup
            // tạm thời dùng giá trị global
            // NOTE: interaction cần biết board size để map tọa độ
            // giải pháp đơn giản: lưu board size khi init
            int cellSize = boardW / boardSize;

            int c = (mouseX - padding) / cellSize;
            int r = (mouseY - padding) / cellSize;

            if (r >= 0 && r < boardSize && c >= 0 && c < boardSize) {
                *row = r;
                *col = c;
                Logger::log(
                    std::format("SDLInteraction: click at ({}, {})", r, c),
                    Logger::Level::DEBUG);
                return true;
            }
            // click ngoài board → invalid, hỏi lại
            return false;
        }
    }
    return false;
}


/**
 * Mô tả: Dọn dẹp tài nguyên liên quan đến SDL interaction.
 * Đầu vào: Không có.
 * Đầu ra: Không có.
 * Tác dụng phụ:
 *   - Giải phóng hoặc reset trạng thái input nếu cần.
 */
void SDLInteraction::close() {
    Logger::log("SDLInteraction closed!");
}

/**
 * Mô tả: Lắng nghe sự kiện SDL (event polling).
 * Đầu vào: Không có.
 * Đầu ra: Không có.
 * Tác dụng phụ: Cập nhật trạng thái event nội bộ.
 */
void SDLInteraction::listenEvent() {
    // Poll một event từ SDL event queue
    hasEvent = SDL_PollEvent(&currentEvent);
    if (hasEvent && currentEvent.type == SDL_QUIT) {
        throw QuitException();
    }
}

/**
 * Mô tả: Xử lý sự kiện và chuyển trạng thái game.
 * Đầu vào:
 *   - currentState: trạng thái game hiện tại.
 *   - setup: thông tin setup game.
 * Đầu ra: GameState mới.
 * Tác dụng phụ: Có thể thay đổi setup nếu cần.
 */
GameState SDLInteraction::handleEvent(GameState currentState, GameSetup& setup) {
    if (!hasEvent) {
        return currentState;  // Không có event, trạng thái không thay đổi
    }

    if (currentEvent.type == SDL_MOUSEBUTTONDOWN && currentEvent.button.button == SDL_BUTTON_LEFT) {
        int mouseX = currentEvent.button.x;
        int mouseY = currentEvent.button.y;
        int centerX = screenWidth / 2;
        int centerY = screenHeight / 2;

        switch (currentState) {
            case GameState::TITLE:
                return GameState::SELECT_SIZE;

            case GameState::SELECT_SIZE: {
                int count = BOARD_N_MAX - 2; // lựa chọn 3..12
                int selected = -1;
                if (resolveGridClick(mouseX, mouseY, count, 5, 100, 70, 20,
                                     centerX, centerY - 10, selected)) {
                    int size = 3 + selected;
                    setup.size = size;
                    Logger::log(std::format("Selected size: {}", size), Logger::Level::DEBUG);
                    return GameState::SELECT_GOAL;
                }
                break;
            }

            case GameState::SELECT_GOAL: {
                int count = setup.size - 2;
                int selected = -1;
                if (resolveGridClick(mouseX, mouseY, count, 5, 100, 70, 20,
                                     centerX, centerY - 10, selected)) {
                    int goal = 3 + selected;
                    setup.goal = goal;
                    Logger::log(std::format("Selected goal: {}", goal), Logger::Level::DEBUG);
                    return GameState::SELECT_MODE;
                }
                break;
            }

            case GameState::SELECT_MODE: {
                int selected = -1;
                if (resolveGridClick(mouseX, mouseY, 3, 1, 320, 70, 20,
                                     centerX, centerY - 50, selected)) {
                    setup.mode = (GameMode)selected;
                    Logger::log(std::format("Selected mode: {}", selected + 1), Logger::Level::DEBUG);
                    if (setup.mode == GameMode::PVE || setup.mode == GameMode::EVE) {
                        return GameState::SELECT_BOT_1;
                    }
                    return GameState::PLAYING;
                }
                break;
            }

            case GameState::SELECT_BOT_1: {
                int selected = -1;
                if (resolveGridClick(mouseX, mouseY, 3, 1, 320, 70, 20,
                                     centerX, centerY - 50, selected)) {
                    setup.levels[1] = (BotLevel)selected;
                    Logger::log(std::format("Selected bot 1 level: {}", selected + 1), Logger::Level::DEBUG);
                    if (setup.mode == GameMode::EVE) {
                        return GameState::SELECT_BOT_2;
                    }
                    return GameState::PLAYING;
                }
                break;
            }

            case GameState::SELECT_BOT_2: {
                int selected = -1;
                if (resolveGridClick(mouseX, mouseY, 3, 1, 320, 70, 20,
                                     centerX, centerY - 50, selected)) {
                    setup.levels[0] = (BotLevel)selected;
                    Logger::log(std::format("Selected bot 2 level: {}", selected + 1), Logger::Level::DEBUG);
                    return GameState::PLAYING;
                }
                break;
            }

            case GameState::GAME_OVER:
                return GameState::TITLE;

            default:
                break;
        }
    }

    return currentState;
}

/**
 * Mô tả: Chờ người dùng chọn chơi lại hay thoát sau khi game kết thúc.
 * Đầu ra:
 *   - 1: chơi lại
 *   - 0: thoát game
 * Tác dụng phụ:
 *   - Block chờ sự kiện từ người dùng
 *   - Có thể ném QuitException nếu đóng cửa sổ
 */
bool SDLInteraction::waitForPlayAgainSelection() {
    SDL_Event e;
    
    while (SDL_WaitEvent(&e)) {
        if (e.type == SDL_QUIT) {
            throw QuitException();
        }
        
        if (e.type == SDL_KEYDOWN) {
            switch (e.key.keysym.sym) {
                case SDLK_y:
                case SDLK_RETURN:
                    return 1;  // Chơi lại
                case SDLK_n:
                case SDLK_ESCAPE:
                    return 0;  // Thoát
                default:
                    break;
            }
        }
        
        if (e.type == SDL_MOUSEBUTTONDOWN) {
            // Click chuột = chơi lại (tạm thời)
            return 1;
        }
    }
    
    return 0;
}