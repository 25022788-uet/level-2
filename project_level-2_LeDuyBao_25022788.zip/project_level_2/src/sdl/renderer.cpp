/**
 * SDL Renderer cpp implementation
 *
 */

#include "renderer.h"

/* ---------- Importing ---------- */

#include <format>
#include <iostream>
#include <algorithm>
#include <vector>

#include "../game/setup.h"
#include "../utils/config.h"
#include "../utils/logger.h"

/* ---------- Global variables ----------*/

// Màu sắc
static const SDL_Color COLOR_BG        = {30, 30, 30, 255};      // nền tối
static const SDL_Color COLOR_GRID      = {80, 80, 80, 255};      // đường kẻ
static const SDL_Color COLOR_X         = {220, 80, 80, 255};     // X màu đỏ
static const SDL_Color COLOR_O         = {80, 150, 220, 255};    // O màu xanh
static const SDL_Color COLOR_WIN       = {255, 215, 0, 255};     // đường thắng màu vàng
static const SDL_Color COLOR_TEXT      = {255, 255, 255, 255};   // text trắng
static const SDL_Color COLOR_SUBTEXT   = {180, 180, 180, 255};   // text phụ xám

// Cấu hình layout
static int SCREEN_W    = 800;
static int SCREEN_H    = 800;
static int BOARD_PAD   = 100;   // padding board so với cửa sổ
static int CELL_SIZE   = 0;     // tính động theo size board
static int BOARD_SIZE  = 0;     // số ô (NxN)

// Font sizes
static const int FONT_SIZE_LARGE  = 24;
static const int FONT_SIZE_MEDIUM = 18;
static const int FONT_SIZE_SMALL  = 14;

/* ---------- Definitions ---------- */

SDLRenderer::SDLRenderer() : window(nullptr), renderer(nullptr) {
}

/**
 * Mô tả: Destructor của SDLRenderer.
 * Đầu vào: Không.
 * Đầu ra: Không.
 * Tác dụng phụ: Không (việc giải phóng thực hiện trong close()).
 */
SDLRenderer::~SDLRenderer() {
}

// ==================== HELPER FUNCTIONS ====================

/**
 * Mô tả: Vẽ hình chữ nhật lên renderer.
 * Đầu vào:
 *   - x, y: tọa độ.
 *   - w, h: kích thước.
 *   - color: màu sắc.
 *   - filled: true nếu fill, false nếu vẽ viền.
 * Đầu ra: Không.
 * Tác dụng phụ: Vẽ trực tiếp lên renderer.
 */
void SDLRenderer::drawRect(int x, int y, int w, int h, SDL_Color color, bool filled) {
    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
    SDL_Rect rect = {x, y, w, h};
    if (filled) {
        SDL_RenderFillRect(renderer, &rect);
    } else {
        SDL_RenderDrawRect(renderer, &rect);
    }
}

/**
 * Mô tả: Hiển thị frame đã render lên màn hình.
 * Đầu vào: Không.
 * Đầu ra: Không.
 * Tác dụng phụ: Swap buffer để hiển thị nội dung.
 */
void SDLRenderer::renderPresent() {
    SDL_RenderPresent(renderer);
}

/**
 * Mô tả: Render text tại vị trí (x, y)
 * Đầu vào:
 *   - renderer: renderer để render text.
 *   - font: font để sử dụng.
 *   - text: chuỗi text cần render.
 *   - x, y: tọa độ.
 *   - color: màu sắc.
 *   - centered: true nếu căn giữa, false nếu không.
 * Đầu ra: Không.
 * Tác dụng phụ: Render text lên renderer.
 */
static void renderText(SDL_Renderer* renderer, TTF_Font* font, const std::string& text,
                       int x, int y, SDL_Color color, bool centered = false) {
    if (!font || text.empty()) return;

    SDL_Surface* surface = TTF_RenderText_Blended(font, text.c_str(), color);
    if (!surface) return;

    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
    if (!texture) {
        SDL_FreeSurface(surface);
        return;
    }

    int w = surface->w;
    int h = surface->h;
    SDL_FreeSurface(surface);

    SDL_Rect dst;
    if (centered) {
        dst = {x - w / 2, y - h / 2, w, h};
    } else {
        dst = {x, y, w, h};
    }

    SDL_RenderCopy(renderer, texture, nullptr, &dst);
    SDL_DestroyTexture(texture);
}

static void drawButton(SDL_Renderer* renderer, TTF_Font* font,
                       const std::string& label, const SDL_Rect& rect) {
    SDL_Color buttonColor = {60, 90, 140, 255};
    SDL_Color borderColor = {220, 220, 220, 255};

    SDL_SetRenderDrawColor(renderer, buttonColor.r, buttonColor.g, buttonColor.b, buttonColor.a);
    SDL_RenderFillRect(renderer, &rect);
    SDL_SetRenderDrawColor(renderer, borderColor.r, borderColor.g, borderColor.b, borderColor.a);
    SDL_RenderDrawRect(renderer, &rect);
    renderText(renderer, font, label,
               rect.x + rect.w / 2,
               rect.y + rect.h / 2,
               COLOR_TEXT, true);
}

static void drawButtonGrid(SDL_Renderer* renderer, TTF_Font* font,
                           const std::vector<std::string>& labels,
                           int cols, int centerX, int startY,
                           int buttonW, int buttonH, int spacing) {
    int count = (int)labels.size();
    int totalWidth = cols * buttonW + (cols - 1) * spacing;
    int leftX = centerX - totalWidth / 2;

    for (int i = 0; i < count; i++) {
        int row = i / cols;
        int col = i % cols;
        SDL_Rect rect = {
            leftX + col * (buttonW + spacing),
            startY + row * (buttonH + spacing),
            buttonW,
            buttonH
        };
        drawButton(renderer, font, labels[i], rect);
    }
}

/**
 * Mô tả: Vẽ chữ X tại ô (row, col)
 * Đầu vào:
 *   - renderer: renderer để vẽ.
 *   - row, col: tọa độ ô.
 *   - pad: padding.
 *   - cellSize: kích thước ô.
 *   - color: màu sắc.
 * Đầu ra: Không.
 * Tác dụng phụ: Vẽ trực tiếp lên renderer.
 */
static void drawX(SDL_Renderer* renderer, int row, int col, int pad, int cellSize, SDL_Color color) {
    int margin = cellSize / 5;
    int x1 = pad + col * cellSize + margin;
    int y1 = pad + row * cellSize + margin;
    int x2 = pad + (col + 1) * cellSize - margin;
    int y2 = pad + (row + 1) * cellSize - margin;

    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);

    // vẽ dày hơn bằng cách vẽ nhiều đường gần nhau
    for (int i = -2; i <= 2; i++) {
        SDL_RenderDrawLine(renderer, x1 + i, y1, x2 + i, y2);
        SDL_RenderDrawLine(renderer, x1, y1 + i, x2, y2 + i);
        SDL_RenderDrawLine(renderer, x1 + i, y2, x2 + i, y1);
        SDL_RenderDrawLine(renderer, x1, y2 + i, x2, y1 + i);
    }
}

/**
 * Vẽ chữ O tại ô (row, col) bằng cách xấp xỉ đường tròn
 */
static void drawO(SDL_Renderer* renderer, int row, int col, int pad, int cellSize, SDL_Color color) {
    int cx = pad + col * cellSize + cellSize / 2;
    int cy = pad + row * cellSize + cellSize / 2;
    int radius = cellSize / 2 - cellSize / 5;

    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);

    // vẽ đường tròn bằng thuật toán Bresenham + vẽ dày
    for (int thickness = -2; thickness <= 2; thickness++) {
        int r = radius + thickness;
        int x = r, y = 0;
        int err = 0;
        while (x >= y) {
            SDL_RenderDrawPoint(renderer, cx + x, cy + y);
            SDL_RenderDrawPoint(renderer, cx + y, cy + x);
            SDL_RenderDrawPoint(renderer, cx - y, cy + x);
            SDL_RenderDrawPoint(renderer, cx - x, cy + y);
            SDL_RenderDrawPoint(renderer, cx - x, cy - y);
            SDL_RenderDrawPoint(renderer, cx - y, cy - x);
            SDL_RenderDrawPoint(renderer, cx + y, cy - x);
            SDL_RenderDrawPoint(renderer, cx + x, cy - y);
            y++;
            err += 2 * y + 1;
            if (2 * (err - x) + 1 > 0) {
                x--;
                err += 1 - 2 * x;
            }
        }
    }
}

// ==================== INTERFACE FUNCTIONS ====================

/**
 * Mô tả: Khởi tạo SDL, window và renderer.
 * Đầu vào: config - cấu hình màn hình và layout.
 * Đầu ra: Không.
 * Tác dụng phụ:
 *   - Khởi tạo SDL subsystem.
 *   - Tạo window và renderer.
 *   - Thiết lập chế độ blend.
 * NOTE: Phải gọi trước khi render.
 */
void SDLRenderer::init(const RunConfig& config) {
    SCREEN_W = config.screenWidth;
    SCREEN_H = config.screenHeight;
    BOARD_PAD = config.boardPadding;

    // khởi tạo SDL
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        Logger::log(std::format("SDL_Init failed: {}", SDL_GetError()), Logger::Level::ERROR);
        return;
    }

    // khởi tạo SDL_ttf
    if (TTF_Init() < 0) {
        Logger::log(std::format("TTF_Init failed: {}", TTF_GetError()), Logger::Level::ERROR);
        return;
    }

    // tải font
    fontLarge  = TTF_OpenFont("assets/fonts/PressStart2P-Regular.ttf", FONT_SIZE_LARGE);
    fontMedium = TTF_OpenFont("assets/fonts/PressStart2P-Regular.ttf", FONT_SIZE_MEDIUM);
    fontSmall  = TTF_OpenFont("assets/fonts/PressStart2P-Regular.ttf", FONT_SIZE_SMALL);

    if (!fontLarge || !fontMedium || !fontSmall) {
        Logger::log(std::format("TTF_OpenFont failed: {}", TTF_GetError()), Logger::Level::ERROR);
    }

    // tạo cửa sổ
    window = SDL_CreateWindow(
        "Tic-Tac-Toe",
        SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED,
        SCREEN_W, SCREEN_H,
        SDL_WINDOW_SHOWN);

    if (!window) {
        Logger::log(std::format("SDL_CreateWindow failed: {}", SDL_GetError()), Logger::Level::ERROR);
        return;
    }

    // tạo renderer
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) {
        Logger::log(std::format("SDL_CreateRenderer failed: {}", SDL_GetError()), Logger::Level::ERROR);
        return;
    }

    // bật blend mode cho alpha
    SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);

    Logger::log("SDLRenderer initialized!");
}


/**
 * Mô tả: Xóa toàn bộ nội dung màn hình (background tối).
 * Đầu vào: Không.
 * Đầu ra: Không.
 * Tác dụng phụ: Reset frame hiện tại.
 */
void SDLRenderer::clearScreen() {
    SDL_SetRenderDrawColor(renderer,
        COLOR_BG.r, COLOR_BG.g, COLOR_BG.b, COLOR_BG.a);
    SDL_RenderClear(renderer);
}

/**
 * Mô tả: Hiển thị menu lựa chọn.
 * Đầu vào: selectType, context.
 * Đầu ra: Không.
 * Tác dụng phụ: Vẽ UI lên màn hình.
 * TODO:
 *   - Bước 1: Xác định loại menu.
 *   - Bước 2: Render text tương ứng.
 *   - Trường hợp biên: selectType không hợp lệ.
 */
void SDLRenderer::showSelectMenu(SelectType selectType, int context) {
    // Chỉ clearScreen() cho menu chính, không cho PLAYER_UI (vì nó được render lên board)
    if (selectType != SelectType::PLAYER_UI) {
        clearScreen();
    }

    int centerX = SCREEN_W / 2;
    int centerY = SCREEN_H / 2;

    switch (selectType) {
        case SelectType::TITLE_UI:
            renderText(renderer, fontLarge,
                "TIC TAC TOE", centerX, centerY - 60,
                COLOR_TEXT, true);
            renderText(renderer, fontSmall,
                "Click anywhere to start", centerX, centerY + 20,
                COLOR_SUBTEXT, true);
            break;

        case SelectType::SIZE_UI: {
            renderText(renderer, fontMedium,
                "Board Size (3-12):", centerX, centerY - 90,
                COLOR_TEXT, true);
            std::vector<std::string> labels;
            for (int value = 3; value <= BOARD_N_MAX; value++) {
                labels.push_back(std::to_string(value));
            }
            drawButtonGrid(renderer, fontSmall, labels,
                           5, centerX, centerY - 20, 100, 70, 20);
            break;
        }

        case SelectType::GOAL_UI: {
            int maxGoal = (context != NO_CONTEXT) ? std::min(context, GOAL_MAX) : GOAL_MAX;
            renderText(renderer, fontMedium,
                std::format("Goal (3-{}):", maxGoal),
                centerX, centerY - 90, COLOR_TEXT, true);
            std::vector<std::string> labels;
            for (int value = 3; value <= maxGoal; value++) {
                labels.push_back(std::to_string(value));
            }
            drawButtonGrid(renderer, fontSmall, labels,
                           5, centerX, centerY - 20, 100, 70, 20);
            break;
        }

        case SelectType::GAME_MODE_UI: {
            renderText(renderer, fontMedium,
                "Game Mode:", centerX, centerY - 120,
                COLOR_TEXT, true);
            std::vector<std::string> labels = {
                "Player vs Player",
                "Player vs Bot",
                "Bot vs Bot"
            };
            drawButtonGrid(renderer, fontSmall, labels,
                           1, centerX, centerY - 40, 320, 70, 20);
            break;
        }

        case SelectType::BOT_LEVEL_UI: {
            renderText(renderer, fontMedium,
                "Bot Level:", centerX, centerY - 120,
                COLOR_TEXT, true);
            std::vector<std::string> labels = {
                "Easy", "Medium", "Hard"
            };
            drawButtonGrid(renderer, fontSmall, labels,
                           1, centerX, centerY - 40, 320, 70, 20);
            break;
        }

        case SelectType::MUL_BOT_LEVEL_UI: {
            renderText(renderer, fontMedium,
                std::format("Bot {} Level:", (context != NO_CONTEXT ? context + 1 : 1)),
                centerX, centerY - 120, COLOR_TEXT, true);
            std::vector<std::string> labels = {
                "Easy", "Medium", "Hard"
            };
            drawButtonGrid(renderer, fontSmall, labels,
                           1, centerX, centerY - 40, 320, 70, 20);
            break;
        }

        case SelectType::PLAYER_UI:
            // intentionally left blank for SDL: instructions rendered inline
            break;

        default:
            break;
    }

    renderPresent();
}

/**
 * Mô tả: Hiển thị thông báo lựa chọn không hợp lệ.
 * Đầu vào: selectType, context.
 * Đầu ra: Không.
 * Tác dụng phụ: Hiển thị thông báo lỗi.
 * TODO:
 *   - Bước 1: Xác định loại lỗi.
 *   - Bước 2: Render text cảnh báo.
 */
void SDLRenderer::showInvalidSelect(SelectType selectType, int context) {
    // flash thông báo lỗi màu đỏ ở góc dưới
    renderText(renderer, fontSmall,
        "Invalid! Try again.", SCREEN_W / 2, SCREEN_H - 60,
        {255, 80, 80, 255}, true);
    renderPresent();
    SDL_Delay(800);  // hiện 0.8 giây rồi tự mất
}

/**
 * Mô tả: Hiển thị thông báo lựa chọn hợp lệ.
 * Đầu vào: selectType, context.
 * Đầu ra: Không.
 * Tác dụng phụ: Hiển thị xác nhận.
 * TODO:
 *   - Bước 1: Xác định loại selection.
 *   - Bước 2: Render thông báo thành công.
 */
void SDLRenderer::showValidSelect(SelectType selectType, int context) {
    // flash thông báo xanh lá
    std::string msg;
    switch (selectType) {
        case SelectType::SIZE_UI:
            msg = std::format("Size: {}x{}", context, context);
            break;
        case SelectType::GOAL_UI:
            msg = std::format("Goal: {}", context);
            break;
        case SelectType::GAME_MODE_UI:
            msg = std::format("Mode: {}", modeToString(context));
            break;
        case SelectType::BOT_LEVEL_UI:
        case SelectType::MUL_BOT_LEVEL_UI:
            msg = std::format("Level: {}", botToString(context));
            break;
        default:
            break;
    }
    if (!msg.empty()) {
        renderText(renderer, fontSmall,
            msg, SCREEN_W / 2, SCREEN_H - 60,
            {80, 220, 80, 255}, true);
        renderPresent();
        SDL_Delay(600);
    }
}

/**
 * Mô tả: Vẽ bàn cờ lên màn hình.
 * Đầu vào: board, size.
 * Đầu ra: Không.
 * Tác dụng phụ: Render grid và ký hiệu.
 * TODO:
 *   - Bước 1: Tính toán layout ô.
 *   - Bước 2: Vẽ grid.
 *   - Bước 3: Vẽ X/O.
 */
void SDLRenderer::displayBoard(const char board[][BOARD_N_MAX], const int size) {
    // cập nhật cell size theo board size
    BOARD_SIZE = size;
    int boardW = SCREEN_W - 2 * BOARD_PAD;
    CELL_SIZE = boardW / size;

    clearScreen();

    // vẽ đường kẻ ngang
    for (int i = 0; i <= size; i++) {
        int y = BOARD_PAD + i * CELL_SIZE;
        SDL_SetRenderDrawColor(renderer,
            COLOR_GRID.r, COLOR_GRID.g, COLOR_GRID.b, COLOR_GRID.a);
        SDL_RenderDrawLine(renderer,
            BOARD_PAD, y,
            BOARD_PAD + size * CELL_SIZE, y);
    }

    // vẽ đường kẻ dọc
    for (int j = 0; j <= size; j++) {
        int x = BOARD_PAD + j * CELL_SIZE;
        SDL_SetRenderDrawColor(renderer,
            COLOR_GRID.r, COLOR_GRID.g, COLOR_GRID.b, COLOR_GRID.a);
        SDL_RenderDrawLine(renderer,
            x, BOARD_PAD,
            x, BOARD_PAD + size * CELL_SIZE);
    }

    // vẽ số hàng và cột
    for (int i = 0; i < size; i++) {
        // số hàng bên trái
        renderText(renderer, fontSmall,
            std::to_string(i),
            BOARD_PAD - 25,
            BOARD_PAD + i * CELL_SIZE + CELL_SIZE / 2,
            COLOR_SUBTEXT, true);

        // số cột phía trên
        renderText(renderer, fontSmall,
            std::to_string(i),
            BOARD_PAD + i * CELL_SIZE + CELL_SIZE / 2,
            BOARD_PAD - 25,
            COLOR_SUBTEXT, true);
    }

    // vẽ X và O
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            if (board[i][j] == 'X') {
                drawX(renderer, i, j, BOARD_PAD, CELL_SIZE, COLOR_X);
            } else if (board[i][j] == 'O') {
                drawO(renderer, i, j, BOARD_PAD, CELL_SIZE, COLOR_O);
            }
        }
    }

    renderPresent();
}

/**
 * Mô tả: Hiển thị nước đi vừa thực hiện.
 * Đầu vào: row, col.
 * Đầu ra: Không.
 * Tác dụng phụ: Highlight ô.
 * TODO:
 *   - Bước 1: Xác định vị trí ô.
 *   - Bước 2: Vẽ highlight.
 */
void SDLRenderer::showMove(const int row, const int col) {
    // đã được vẽ trong displayBoard rồi, không cần làm gì thêm
    Logger::log(std::format("Move shown at ({}, {})", row, col), Logger::Level::DEBUG);
}

/**
 * Mô tả: Hiển thị thông báo nước đi không hợp lệ.
 * Đầu vào: Không.
 * Đầu ra: Không.
 * Tác dụng phụ: Hiển thị lỗi.
 * TODO:
 *   - Bước 1: Render thông báo lỗi.
 */
void SDLRenderer::showInvalidMove() {
    renderText(renderer, fontSmall,
        "Invalid move!", SCREEN_W / 2, SCREEN_H - 60,
        {255, 80, 80, 255}, true);
    renderPresent();
    SDL_Delay(600);
}

/**
 * Mô tả: Hiển thị người chơi hiện tại.
 * Đầu vào: player, is_bot.
 * Đầu ra: Không.
 * Tác dụng phụ: Hiển thị thông tin turn.
 * TODO:
 *   - Bước 1: Xác định text.
 *   - Bước 2: Render lên màn hình.
 */
void SDLRenderer::showPlayer(const int player, const bool is_bot) {
    std::string msg;
    SDL_Color color;

    if (is_bot) {
        msg = std::format("Bot {} thinking...", player + 1);
        color = COLOR_SUBTEXT;
    } else {
        msg = std::format("Player {} turn", player + 1);
        color = (player == 0) ? COLOR_X : COLOR_O;
    }

    // xóa vùng text phía dưới (chỉ phần nằm dưới board) rồi vẽ lại
    int boardBottom = BOARD_PAD + BOARD_SIZE * CELL_SIZE; // y của mép dưới board
    int clearStart = std::max(boardBottom + 4, SCREEN_H - 100); // bắt đầu xóa thấp hơn mép board
    if (clearStart < 0) clearStart = 0;
    int clearHeight = std::max(SCREEN_H - clearStart, 0);
    if (clearHeight > 0) drawRect(0, clearStart, SCREEN_W, clearHeight, COLOR_BG, true);

    // render text ở giữa vùng được xóa (an toàn, không chồng lên border)
    int textY = clearStart + clearHeight / 2;
    renderText(renderer, fontMedium, msg, SCREEN_W / 2, textY,
        color, true);
    renderPresent();
}

/**
 * Mô tả: Hiển thị kết quả game.
 * Đầu vào: winner, is_bot, winLine.
 * Đầu ra: Không.
 * Tác dụng phụ: Hiển thị kết quả và highlight đường thắng.
 * TODO:
 *   - Bước 1: Kiểm tra draw hoặc win.
 *   - Bước 2: Render text.
 *   - Bước 3: Highlight winLine nếu có.
 */
void SDLRenderer::showResult(const int winner, const bool is_bot,
                              const WinLine* winLine) {
    // highlight đường thắng nếu có
    if (winLine && CELL_SIZE > 0) {
        for (auto [r, c] : winLine->cells) {
            // vẽ ô thắng màu vàng
            SDL_SetRenderDrawColor(renderer,
                COLOR_WIN.r, COLOR_WIN.g, COLOR_WIN.b, 80);
            SDL_Rect cell = {
                BOARD_PAD + c * CELL_SIZE + 2,
                BOARD_PAD + r * CELL_SIZE + 2,
                CELL_SIZE - 4,
                CELL_SIZE - 4
            };
            SDL_RenderFillRect(renderer, &cell);
        }
    }

    // hiển thị kết quả
    std::string msg;
    SDL_Color color;

    if (winner == DRAW_RESULT) {
        msg = "It's a Draw!";
        color = COLOR_SUBTEXT;
    } else if (is_bot) {
        msg = std::format("Bot {} Wins!", winner + 1);
        color = (winner == 0) ? COLOR_X : COLOR_O;
    } else {
        msg = std::format("Player {} Wins!", winner + 1);
        color = (winner == 0) ? COLOR_X : COLOR_O;
    }

    // vẽ background text
    drawRect(0, SCREEN_H - 100, SCREEN_W, 100, {0, 0, 0, 180}, true);
    renderText(renderer, fontLarge, msg, SCREEN_W / 2, SCREEN_H - 60,
        color, true);

    renderPresent();
}

void SDLRenderer::showPlayAgainMenu() {
    const int buttonW = 180;
    const int buttonH = 70;
    const int spacing = 24;
    const int centerX = SCREEN_W / 2;
    const int menuY = SCREEN_H - 160;

    std::vector<std::string> labels = {"Play Again", "Quit"};
    drawButtonGrid(renderer, fontMedium, labels, 2, centerX, menuY,
                   buttonW, buttonH, spacing);
    renderPresent();
}

/**
 * Mô tả: In kết quả ra stdout (judge mode).
 * Đầu vào: gameResult.
 * Đầu ra: Không.
 * Tác dụng phụ: In console.
 * TODO:
 *   - Bước 1: Format output.
 *   - Bước 2: In ra std::cout.
 */
void SDLRenderer::printResult(const GameResult& gameResult) {
    // judge mode → in ra console như terminal
    std::cout << gameResult.winner << " " << gameResult.turns << "\n";
}

/**
 * Mô tả: Giải phóng tài nguyên SDL.
 * Đầu vào: Không.
 * Đầu ra: Không.
 * Tác dụng phụ:
 *   - Destroy renderer và window.
 *   - Shutdown SDL subsystem.
 */
void SDLRenderer::close() {
    // giải phóng font
    if (fontLarge)  TTF_CloseFont(fontLarge);
    if (fontMedium) TTF_CloseFont(fontMedium);
    if (fontSmall)  TTF_CloseFont(fontSmall);

    // giải phóng renderer và window
    if (renderer) SDL_DestroyRenderer(renderer);
    if (window)   SDL_DestroyWindow(window);

    // đóng SDL
    TTF_Quit();
    SDL_Quit();

    Logger::log("SDLRenderer closed!");
}

/**
 * Mô tả: Render UI dựa trên trạng thái game (dùng cho state-based loop).
 * Đầu vào:
 *   - state: trạng thái game hiện tại.
 *   - setup: thông tin setup game.
 * Đầu ra: Không.
 * Tác dụng phụ: Vẽ UI tương ứng với state.
 */
void SDLRenderer::render(GameState state, const GameSetup& setup) {
    switch (state) {
        case GameState::TITLE:
            showSelectMenu(SelectType::TITLE_UI);
            break;
        case GameState::SELECT_SIZE:
            showSelectMenu(SelectType::SIZE_UI);
            break;
        case GameState::SELECT_GOAL:
            showSelectMenu(SelectType::GOAL_UI, setup.size);
            break;
        case GameState::SELECT_MODE:
            showSelectMenu(SelectType::GAME_MODE_UI);
            break;
        case GameState::SELECT_BOT_1:
            showSelectMenu(SelectType::BOT_LEVEL_UI);
            break;
        case GameState::SELECT_BOT_2:
            showSelectMenu(SelectType::MUL_BOT_LEVEL_UI, 1);
            break;
        case GameState::PLAYING:
            displayBoard(setup.board, setup.size);
            showSelectMenu(SelectType::PLAYER_UI);
            break;
        case GameState::GAME_OVER:
            // TODO: render game over screen
            clearScreen();
            renderPresent();
            break;
        default:
            break;
    }
}