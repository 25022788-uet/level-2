=== TIC-TAC-TOE LEVEL 2 - HƯỚNG DẪN NHANH ===

1. CÀI ĐẶT MÔI TRƯỜNG (MSYS2 UCRT64)

Mở terminal UCRT64, chạy lần lượt:

pacman -Syu
pacman -S mingw-w64-ucrt-x86_64-make mingw-w64-ucrt-x86_64-cmake mingw-w64-ucrt-x86_64-pkg-config
pacman -S mingw-w64-ucrt-x86_64-SDL2 mingw-w64-ucrt-x86_64-SDL2_ttf

Kiểm tra: g++ --version && cmake --version && pkg-config --modversion sdl2

2. BIÊN DỊCH

cd /đường/dẫn/level-2
mkdir build && cd build
cmake ..
cmake --build .

3. CHẠY CHƯƠNG TRÌNH

./game.exe                 # Terminal mode (mặc định)
./game.exe -g              # SDL mode (đồ họa)
./game.exe -j -i input.txt # Judge mode
./game.exe -v -l           # Debug mode (log ra terminal)

4. FLAG HỖ TRỢ

-g          Bật giao diện SDL
-j          Chế độ chấm điểm
-i <file>   Đọc input từ file
-l <file>   Ghi log ra file (bỏ <file> để in ra terminal)
-v          Bật log mức DEBUG

5. XỬ LÝ LỖI THƯỜNG GẶP

- "cmake: command not found" → cài lại cmake
- "undefined reference SDL" → cài SDL2: pacman -S mingw-w64-ucrt-x86_64-SDL2
- Không thấy font → copy fonts vào assets/fonts/
- Build lỗi → xóa thư mục build, tạo lại

6. DỌN DẸP

rm -rf build   # Windows: rmdir /s build